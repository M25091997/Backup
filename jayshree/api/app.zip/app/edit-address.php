<?php
session_start();
include('../../config.php');

$address_id = $_POST['address-id'];

$full_address = $_POST['full_address'];
$landmark = $_POST['landmark'];
$pincode = $_POST['pincode'];
$address_type = $_POST['address_type'];

$result = array();

if (isset($_POST['address-id'])) {

if ($conn -> query("UPDATE saved_address SET full_address ='$full_address' WHERE id = '$address_id'" ) 

&& $conn -> query("UPDATE saved_address SET landmark = '$landmark' WHERE id = '$address_id'" )

&& $conn -> query("UPDATE saved_address SET pincode = '$pincode' WHERE id = '$address_id'" )

&& $conn -> query("UPDATE saved_address SET address_type = '$address_type' WHERE id = '$address_id'" )

) { array_push($result, array( 'response' => '1' ) ); }

} else { array_push($result, array( 'response' => '888' ) ); /* No Sessions Mismatch */ } 

echo json_encode($result);