<?php
session_start();
include('../../config.php');

$result = array();

$account_id = $_POST['account-id'];
$rating = $_POST['rating'];
$review = $_POST['review'];
$item_id = $_POST['item-id'];

$date_ = date("Y-m-d");
$time_ = date("h:i:s");

$sql = "INSERT INTO ratings (account_id, rating, review, item_id, date_creation, time_creation)
VALUES ('$account_id', '$rating', '$review', '$item_id', '$date_', '$time_')";

if ($conn->query($sql) === TRUE) { 
 array_push($result, array('response' => '1'));
} else {
  array_push($result, array('response' => "Error: " . $sql . "-" . $conn->error ));
} 

echo json_encode($result); ?>