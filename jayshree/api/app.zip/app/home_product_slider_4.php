<?php 
include ("../../config.php"); 

#Top Groceries

$result = array();

$Q = $conn -> query("SELECT * FROM items WHERE category_id = '27' ORDER BY id DESC LIMIT 20 ");

  while ($itemData = mysqli_fetch_array($Q)) { 

        $name = $itemData['name'];
        $item_id = $itemData['id'];
        $media_number = $itemData['media_number'];
        $item_url = $site_url."/item/".$itemData['slug'];
        $QIMG = $conn -> query("SELECT * FROM media WHERE media_number = '$media_number' ");

                            while ($img_data = mysqli_fetch_array($QIMG)) {
                                $img = $site_url."/media/".$img_data['file_name'];
  							}

      $attr_q = $conn -> query("SELECT * FROM attributes WHERE item_id = '$item_id' LIMIT 1 "); 
        while ($item_Data = mysqli_fetch_array($attr_q)) { 

                              $off = "Rs. ".( $item_Data['mrp'] - $item_Data['price'] ). " Off";
                              $mrp = $item_Data['mrp'];
                              $price = $item_Data['price'];
                              $attribute_name = $item_Data['name'];
        }

  array_push($result, array( 'item-name' => substr($name, 0, 23)."...", 'item-id' => $item_id, 'image' => $img, 'mrp' => $mrp, 'price' => $price, 'discount' => $off, 'attribute-name' => $attribute_name  ));

} 

echo json_encode($result);

?>