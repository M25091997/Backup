<?php session_start();
include('../../config.php');

$id = $_POST['id'];
$result = array();

if (isset($_POST['id']) && isset($_POST['id']) != "" ) {

$msg_query_T = $conn -> query("SELECT * FROM items WHERE id = '$id'");

$total_products = mysqli_num_rows($msg_query_T);


            while ($msg_q = mysqli_fetch_array($msg_query_T)) {              
              $category_id = $msg_q['sub_category_id'];
			       }



$product_array = array();


$msg_query = $conn -> query("SELECT * FROM items WHERE sub_category_id = '$category_id' ORDER BY id DESC LIMIT 50");


$total_products = mysqli_num_rows($msg_query);

            while ($msg_q = mysqli_fetch_array($msg_query)) {

              $product_name = $msg_q['name'];
              $product_media_number = $msg_q['media_number'];

              $item_id = $msg_q['id'];
              $availability = $msg_q['availability'];

              	$media_q = $conn -> query("SELECT * FROM media WHERE media_number = '$product_media_number'");
              	while ($media_D = mysqli_fetch_array($media_q)) {

              		$product_img = $site_url."/media/".$media_D['file_name'];

              	}


                $media_q_c = $conn -> query("SELECT * FROM cover_media WHERE media_number = '$product_media_number'");
                if (mysqli_num_rows($media_q_c) != 0) {
                  while ($media_D_c = mysqli_fetch_array($media_q_c)) {
                  $product_img = $site_url."/media/".$media_D_c['file_name'];
                }
                }


                $attr_q = $conn -> query("SELECT * FROM attributes WHERE item_id = '$item_id' LIMIT 1 "); 
        while ($item_Data = mysqli_fetch_array($attr_q)) { 

                              $off = "Rs. ".( $item_Data['mrp'] - $item_Data['price'] ). " Off";
                              $mrp = $item_Data['mrp'];
                              $price = $item_Data['price'];
                              $attribute_name = $item_Data['name'];
        }


              array_push($result, array('id' => $item_id, 'name' => $product_name, 'image' => $product_img, 'mrp' => $mrp, 'price' => $price, 'discount' => $off, 'attribute-name' => $attribute_name ));

			}




} else { array_push($result, array('Error' => "NO POST VARS FOUND")); }



echo json_encode($result);



?>