<?php
session_start();
include('../../config.php');

$result = array();

$item_id = $_POST['item-id'];
        $q = $conn -> query("SELECT * FROM ratings WHERE item_id = '$item_id' ORDER BY id DESC ");

        while ($R_D = mysqli_fetch_array( $q )) { 

            $account_id = $R_D['account_id'];

            $AQ = $conn -> query("SELECT * FROM accounts WHERE id = '$account_id'");

            while ($AD = mysqli_fetch_array($AQ)) {
                $account_name = $AD['name'];
            }

            $rating = $R_D['rating'];
            $review = $R_D['review'];

            array_push($result, array('rating-id' => $R_D['id'], 'rating' => $rating, 'review' => $review, 'account-name' => $account_name, 'date' => time_elapsed_string($R_D['date_creation'].' '.$R_D['time_creation']) ));

}

echo json_encode($result);

?>