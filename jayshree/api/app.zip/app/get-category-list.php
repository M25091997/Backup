<?php session_start(); ?>
<?php include ("../../config.php"); 

$result = array();

$CQ = $conn -> query("SELECT * FROM super_category");

while ($LData = mysqli_fetch_array($CQ)) {
	array_push($result, array('category-id' => $LData['id'], 'name' => $LData['name'], 'icon' => $site_url."/api/app/icons/".$LData['icon'], 'coming-soon' => $LData['coming_soon']));
}

echo json_encode($result);

?>