<?php
session_start();
include('../../config.php');
$result = array();
$account_id = $_POST['account-id'];
$Q = $conn -> query("SELECT * FROM saved_address WHERE account_id = '$account_id'");
while ($DQ = mysqli_fetch_array($Q)) {
	array_push($result, array( 'address-id' => $DQ['id'], 'address-type' => $DQ['address_type'], 'full-address' => $DQ['full_address'], 'landmark' => $DQ['landmark'], 'pincode' => $DQ['pincode'] ));
}
echo json_encode($result);

?>