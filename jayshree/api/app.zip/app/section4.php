<?php

session_start();

include('../inc/app.php');



$result = array();



$msg_query = $conn -> query("SELECT * FROM section_4");



            while ($msg_q = mysqli_fetch_array($msg_query)) {

              $message = $msg_q['file_name'];

              array_push($result, array('img' => $message));

}





echo json_encode($result);



?>