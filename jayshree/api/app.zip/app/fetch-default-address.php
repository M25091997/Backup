<?php
session_start();
include('../../config.php');
$result = array();
$id = $_POST['account-id'];
$Q = $conn -> query("SELECT * FROM accounts WHERE id = '$id'");
$DQ = $Q -> fetch_assoc();

array_push($result, array('full-address' => $DQ['full_address'], 'landmark' => $DQ['landmark'], 'pincode' => $DQ['pincode'] ));

echo json_encode($result);

?>