<?php
session_start();
include('../../config.php');
$dlete_cart_item = array();
$cart_id = $_POST['address-id'];


$sql = "DELETE FROM saved_address WHERE id='$cart_id'";

if ($conn->query($sql) === TRUE) {

 array_push($dlete_cart_item, array('response' => '1' )); 

} else { array_push($dlete_cart_item, array('response' => '0' ));  }


echo json_encode($dlete_cart_item);

?>