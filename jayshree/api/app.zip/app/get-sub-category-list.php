<?php session_start(); ?>
<?php include ("../../config.php"); 

$result = array();

$id = $_POST['super-category-id'];

$CQ = $conn -> query("SELECT * FROM category WHERE super_category_id = '$id'");

while ($LData = mysqli_fetch_array($CQ)) {
	array_push($result, array('sub-category-id' => $LData['id'], 'name' => $LData['name']));
}

echo json_encode($result);

?>