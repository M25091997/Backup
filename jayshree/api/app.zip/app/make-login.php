<?php
session_start();
include('../../config.php');

$result = array();

$phone = $_POST['email'];
$password = $_POST['password'];

$account_arr = $conn -> query("SELECT * FROM accounts WHERE email = '$phone' AND password = '$password'");

$account_arr2 = $conn -> query("SELECT * FROM accounts WHERE phone = '$phone' AND password = '$password'");

if ( mysqli_num_rows($account_arr) != 0 OR mysqli_num_rows($account_arr2) != 0 ) {

	if( mysqli_num_rows($account_arr) != 0 ){
	while ( $row = mysqli_fetch_array($account_arr) ) {

	$account_id = $row['id'];
	$address = $row['full_address'];

	}
	}


	if( mysqli_num_rows($account_arr2) != 0 ){
	while ( $row = mysqli_fetch_array($account_arr2) ) {

	$account_id = $row['id'];
	$address = $row['full_address'];

	}
	}

	array_push($result, array( 'response' => '1', 'account-id' => $account_id, 'address' => $address ));

} else { array_push($result, array( 'response' => '444' )); }

echo json_encode($result);