<?php
session_start();
include('../../config.php');
$result = array();
if (isset($_POST['process-id'])) {

$process_id = $_POST['process-id'];

$OQ = $conn -> query("SELECT * FROM orders WHERE process_id = '$process_id'");

while ($OData = mysqli_fetch_array($OQ)) {

	/*Fetching Cart Id*/
	$Cart_ID = $OData['cart_id'];

	$CQ = $conn -> query("SELECT * FROM cart WHERE id = '$Cart_ID'");


	while ($CData = mysqli_fetch_array($CQ)) {


		$Attribute_ID = $CData['attribute_id'];

		/*Fetching Item Current Rate*/
		$PQ = $conn -> query("SELECT * FROM attributes WHERE id = '$Attribute_ID'");
		$AttributeData = $PQ -> fetch_assoc();

		
		/*Re Adding To Cart*/


				try {

		    $conn_P = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUsername, $dbPassword);

		    // set the PDO error mode to exception

		    $conn_P->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		     // prepare sql and bind parameters

		    $stmt = $conn_P->prepare("INSERT INTO cart (item_id, attribute_id, account_id, date_creation, quantity, total_amount) 

		    VALUES (:item_id, :attribute_id, :account_id, :date_creation, :quantity, :total_amount)");

		    $stmt->bindParam(':item_id', $item_id);
		    $stmt->bindParam(':attribute_id', $attribute_id);
		    $stmt->bindParam(':account_id', $account_id);
		    $stmt->bindParam(':date_creation', $date_creation);
		    $stmt->bindParam(':quantity', $quantity);
		    $stmt->bindParam(':total_amount', $total_amount);


		$item_id = $CData['item_id'];
		$attribute_id = $CData['attribute_id'];
		$account_id = $CData['account_id'];
		$date_creation = date('Y-m-d');
		$quantity = $CData['quantity'];
		$total_amount = ( $AttributeData['price'] * $CData['quantity'] );

		/*Checking Stock then executing*/
		if ( $AttributeData['stock'] >= $quantity ) { $flag = $stmt -> execute(); }	
		


		}

		catch(PDOException $e)

		    {
		    echo "Error: ".$e->getMessage();
		    }

		$conn_P = null;



		/*Re Adding To Cart Ends*/

	}


}

if ( true ) { array_push($result,  array('response' => '1')); }

} else { array_push($result,  array('response' => 'POST VAR MISSING')); }

echo json_encode($result);
?>