<?php include("../../../config.php");

$reason = $_GET['reason'];
$order_id = $_GET['order-id'];
$by = $_GET['by'];

     $cQ = $conn -> query("SELECT * FROM bookings WHERE id = '$order_id' ORDER BY id DESC "); 
	 while ($rowD = mysqli_fetch_array($cQ)) { $account_id = $rowD['account_id'];  }

	 $aQ = $conn -> query("SELECT * FROM accounts WHERE id = '$account_id'");
     while ($sD = mysqli_fetch_array($aQ)) { $mobile = $sD['phone']; }

     $U = $conn -> query("UPDATE bookings SET cancelled_by = '$by' WHERE id = '$order_id'");
     $U2 = $conn -> query("UPDATE bookings SET cancelled_reason = '$reason' WHERE id = '$order_id'");

     $R4 = $conn->query("UPDATE bookings SET order_status = '5' WHERE id = '$order_id' ");

    /*When Order is has been shipped and in transit*/
    _SEND_MESSAGE($mobile, "Dear Customer, Your Order #".$order_id."has been cancelled. Reason: ".$reason."\nThank You.\nCityindia.in");

	if ($by == "CUSTOMER") { header('Location: cancelled.php?id='.$order_id); } else { header('Location: all-orders.php'); }

    


?>