<!DOCTYPE html>
<html>
<head>
	  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Cancel Order:: CityIndia</title>
	<link rel="stylesheet" type="text/css" href="https://cityindia.in/account/vendor/bootstrap/css/bootstrap.min.css">
	<script src="https://cityindia.in/account/vendor/jquery/jquery-3.2.1.min.js"></script>

</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12 col-xs-12">
			
	<h3>Hii, We just want to know what went wrong!</h3>
	

	<textarea class="reason form-control" style="height: 80px;" placeholder="Please Enter the reason for cancellation of ORDER #<?php echo $_GET['id']; ?>"></textarea>
	<br>
	<center><button class="btn btn-primary cn-button" type="button">Cancel Order Now</button></center>
	

		</div>
	</div>
</div>

</body>
</html>

<script type="text/javascript">
	$(".cn-button").click(function(){
		window.location.href="cancel-order-api.php?order-id=<?php echo $_GET['id']; ?>&reason="+$(".reason").val()+'&by=CUSTOMER'
	});
</script>