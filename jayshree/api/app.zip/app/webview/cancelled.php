<!DOCTYPE html>
<html>
<head>
	  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Cancel Order:: CityIndia</title>
	<link rel="stylesheet" type="text/css" href="https://cityindia.in/account/vendor/bootstrap/css/bootstrap.min.css">
	<script src="https://cityindia.in/account/vendor/jquery/jquery-3.2.1.min.js"></script>

</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12 col-xs-12">
			
	

	<center>
		
	<h3>Your Order #<?php echo $_GET['id']; ?> is Successfully Cancelled!</h3>
		<img src="cancel.png" class="img-responsive" />
	</center>
	

		</div>
	</div>
</div>

</body>
</html>