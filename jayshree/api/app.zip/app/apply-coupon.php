<?php include("../../config.php");

$result = array();

if ( isset($_POST['customer-id']) && isset($_POST['amount']) && isset($_POST['coupon-code']) ) {

if (APPLY_COUPON($_POST['coupon-code'], $_POST['amount'])) {

$discounted_value = intval ( APPLY_COUPON( $_POST['coupon-code'], $_POST['amount'] ) ); 

$result = array('response' => '1', 'text' => "Congratulation! Rs.".($_POST['amount'] - $discounted_value)." Discount Coupon Has been Applied to your invoice, Enjoy!", 'discounted_amount' => $discounted_value, 'discount' => ( $_POST['amount'] - $discounted_value )  );

}else{ $result = array('response' => 'Invalid or Coupon Code not Applicable' ); }

} else{ $result = array('response' => '666'); /*Missing Post Variables*/ }

//Json Output
echo json_encode($result); ?>