<?php
session_start();
include('../../config.php');
$result = array();

	$otp = $_POST['otp-n'];
    $account_id = $_POST['account_to_verify'];

    if ($conn -> query("UPDATE accounts SET verification = '1' WHERE id = '$account_id'" )) { 
                array_push($result, array( 'response' => '1' ) ); /* OTP Matched */
            } else { array_push($result, array( 'response' => '0' ) ); /* OTP Miss Matched */ }

echo json_encode($result); ?>